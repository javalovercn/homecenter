A. PC Server side
   1 Install Oracle(Sun) JRE 6 or later, http://www.java.com/en/download/manual.jsp
   2 run "HomeCenter.bat" in Windows or "HomeCenter.sh" in Unix or double click starter.jar to run Server Java Application.

B. Mobile side
   1 If Android, install mobile/hcME.apk; If QRcode, please http://homecenter.mobi/en/pc/downloads.htm
   2 If Java (j2me) mobile phone, install mobile/hcME.jar; If QRcode, please http://homecenter.mobi/en/pc/downloads.htm
   3 If Windows CE, see http://homecenter.mobi/en/pc/faq.htm#item11

C. FAQ
   1 more FAQ, please click http://homecenter.mobi/en/pc/faq.htm