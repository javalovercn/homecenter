A. PC Server side
   1 Install Oracle(Sun) JRE 6 or later, http://www.java.com/en/download/manual.jsp
   2 run "HomeCenter.bat" in Windows or "HomeCenter.sh" in Unix or double click starter.jar to run Server Java Application.

B. Mobile side
   1 If Java mobile phone, please install hcME.jar or http://homecenter.mobi/download/hcME.jar ; If bar code, please http://homecenter.mobi/en/pc/downloads.htm
   2 If Android smart phone, please install hcME.apk or http://homecenter.mobi/download/hcME.apk ; If bar code, please http://homecenter.mobi/en/pc/downloads.htm
   2.1  If your Android mobile also support Java, We suggest using Java.
   3 If Windows CE, see http://homecenter.mobi/en/pc/faq.htm#item11

C. FAQ
   1 more FAQ, please click http://homecenter.mobi/en/pc/faq.htm