package hc;

import hc.res.ImageSrc;
import hc.server.ui.tip.TipPop;
import hc.util.PropertiesManager;
import hc.util.ResourceUtil;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Image;
import java.awt.Point;
import java.awt.TrayIcon.MessageType;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;

import javax.swing.ImageIcon;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.ToolTipManager;

public class LinuxTrayIcon extends JDialog implements ITrayIcon {
	final JLabel icon = new JLabel();
	Image image;
	final int MAX_IMG_SIZE = 32;
	boolean autoResize = false;
	ActionListener defaultAction;
	MouseListener iconMouseListener;
	int dragStartX, dragStartY, locX, locY;
	boolean isDraged = false;
	
	public LinuxTrayIcon(){
		setAlwaysOnTop(true);
		setUndecorated(true);//去掉窗口的边框
		
		try{
			com.sun.awt.AWTUtilities.setWindowOpaque(this, false);//透明
		}catch (Throwable e) {
			setBackground(new Color(0,0,0,0));
		}
		icon.setOpaque(false);
		
		getContentPane().setLayout(new BorderLayout());
		getContentPane().add(icon, BorderLayout.CENTER);
		icon.addMouseMotionListener(new MouseMotionListener() {
			
			@Override
			public void mouseMoved(MouseEvent e) {
//				L.V = L.O ? false : LogManager.log("mouseMoved , x : " + e.getXOnScreen() + ", y : " + e.getYOnScreen());
			}
			
			@Override
			public void mouseDragged(MouseEvent e) {
				isDraged = true;
				setLocation(locX + (e.getXOnScreen() - dragStartX), locY + (e.getYOnScreen() - dragStartY));
//				L.V = L.O ? false : LogManager.log("mouseDragged , x : " + e.getXOnScreen() + ", y : " + e.getYOnScreen());
			}
		});
		icon.addMouseListener(new MouseListener() {
			
			@Override
			public void mouseReleased(MouseEvent e) {
				dragStartX = 0;
				dragStartY = 0;
				if(isDraged){
					saveLocation();
				}
				isDraged = false;
//				L.V = L.O ? false : LogManager.log("mouseReleased , x : " + e.getXOnScreen() + ", y : " + e.getYOnScreen());
				if(iconMouseListener != null){
					iconMouseListener.mouseReleased(e);
				}
			}
			
			@Override
			public void mousePressed(MouseEvent e) {
				TipPop.close();

				dragStartX = e.getXOnScreen();
				dragStartY = e.getYOnScreen();
				
				final Point location = getLocation();
				locX = location.x;
				locY = location.y;

				if(iconMouseListener != null){
					iconMouseListener.mousePressed(e);
				}
			}
			
			@Override
			public void mouseExited(MouseEvent e) {
//				if(iconMouseListener != null){
//					iconMouseListener.mouseExited(e);
//				}
				ToolTipManager.sharedInstance().mouseExited(e);
			}
			
			@Override
			public void mouseEntered(MouseEvent e) {
//				if(iconMouseListener != null){
//					iconMouseListener.mouseEntered(e);
//				}
				ToolTipManager.sharedInstance().mouseEntered(e);
			}
			
			@Override
			public void mouseClicked(final MouseEvent e) {
				if(defaultAction != null){
					if(e.getButton() == MouseEvent.BUTTON1 && e.getClickCount() == 1){
						defaultAction.actionPerformed(null);
						return;
					}
				}
				if(iconMouseListener != null){
					iconMouseListener.mouseClicked(e);
				}
			}
		});
	}
	
	@Override
	public void setToolTip(String tooltip) {
		icon.setToolTipText(tooltip);
	}

	@Override
	public void setImage(Image image) {
		if(this.image == image){
			return;
		}
		this.image = image;
		Image iconImage = image;
		if(autoResize && (image.getWidth(null) > MAX_IMG_SIZE)){
			iconImage = ResourceUtil.resizeImage(ResourceUtil.toBufferedImage(image), MAX_IMG_SIZE, MAX_IMG_SIZE);
		}
		iconImage = ImageSrc.makeRoundedCorner(ImageSrc.toBufferedImage(iconImage), 12);
		icon.setIcon(new ImageIcon(iconImage));
		if(PropertiesManager.getValue(PropertiesManager.p_TrayX) == null){
			Dimension d = ResourceUtil.getScreenSize();
			setLocation(d.width - 2 * image.getWidth(null),
					d.height - 2 * image.getHeight(null));
			saveLocation();
		}else{
			setLocation(Integer.parseInt(PropertiesManager.getValue(PropertiesManager.p_TrayX)), 
					Integer.parseInt(PropertiesManager.getValue(PropertiesManager.p_TrayY)));
		}
		
		this.pack();
	}

	private void saveLocation() {
		Point location = this.getLocation();
		PropertiesManager.setValue(PropertiesManager.p_TrayX, String.valueOf(location.x));
		PropertiesManager.setValue(PropertiesManager.p_TrayY, String.valueOf(location.y));
		PropertiesManager.saveFile();
	}

	@Override
	public Image getImage() {
		return image;
	}
	
	@Override
	public void setImageAutoSize(boolean autosize) {
		this.autoResize = autosize;
	}

	@Override
	public void removeTrayMouseListener(MouseListener listener) {
		iconMouseListener = null;
	}

	@Override
	public void addTrayMouseListener(MouseListener listener) {
		iconMouseListener = listener;
	}

	@Override
	public void removeTray(){
		this.dispose();
		TipPop.exit();
	}

	@Override
	public void setDefaultActionListener(ActionListener listen) {
		this.defaultAction = listen;
	}

	@Override
	public void displayMessage(String caption, String text,
			MessageType messageType) {
		final Point location = this.getLocation();
		TipPop.setCornerPosition(location.x, location.y, icon.getWidth(), icon.getHeight());
		TipPop.displayMessage(caption, text, messageType);
	}

	@Override
	public void showTray() {
		this.setVisible(true);
	}
}