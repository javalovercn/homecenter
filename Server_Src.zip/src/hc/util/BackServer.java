package hc.util;

import hc.core.ContextManager;
import hc.core.IContext;
import hc.core.L;
import hc.core.MsgBuilder;
import hc.core.data.DataPNG;
import hc.core.util.ByteUtil;
import hc.core.util.HCURL;
import hc.core.util.HCURLUtil;
import hc.core.util.IHCURLAction;
import hc.core.util.LogManager;
import hc.core.util.StringUtil;
import hc.server.data.screen.KeyComper;

import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.io.IOException;

import javax.imageio.ImageIO;

public abstract class BackServer implements IBiz, IHCURLAction{
	public static final String EVENT_SYS_MOBILE_LOGOUT = "SYS_MOBILE_LOGOUT";
	public static final String EVENT_SYS_MOBILE_LOGIN = "SYS_MOBILE_LOGIN";
	public static final String EVENT_SYS_PROJ_STARTUP = "SYS_PROJ_STARTUP";
	public static final String EVENT_SYS_PROJ_SHUTDOWN = "SYS_PROJ_SHUTDOWN";
	public static final String[] EVENT_LIST = {
		EVENT_SYS_PROJ_STARTUP,
		EVENT_SYS_MOBILE_LOGIN, EVENT_SYS_MOBILE_LOGOUT,
		EVENT_SYS_PROJ_SHUTDOWN};

	public abstract void stop();
	public abstract void enterContext(String contextName);
	
	public abstract Object onEvent(Object event);
	
	public static void tipOnTray(final String msg){
		ContextManager.displayMessage((String) ResourceUtil.get(IContext.INFO), 
				msg, IContext.INFO, 0);
	}

	public static void sendAUSound(byte[] bs) {
		try{
	        final long length = bs.length;
	    
	        final int HEAD = DataPNG.HEAD_LENGTH + MsgBuilder.INDEX_MSG_DATA;
			final byte[] bytes = ByteUtil.byteArrayCacher.getFree((int)length + HEAD);
	        System.arraycopy(bs, 0, bytes, HEAD, bs.length);
	
	        DataPNG blob = new DataPNG();
	        blob.bs = bytes;
	        
	        blob.setPNGDataLen((int)length, 0, 0 , 0, 0);
	        ContextManager.getContextInstance().sendWrap(MsgBuilder.E_SOUND, bytes, MsgBuilder.INDEX_MSG_DATA, 
	        		(int)length + DataPNG.HEAD_LENGTH);
	        
	        ByteUtil.byteArrayCacher.cycle(bytes);
	        
	        LogManager.log("AU length:" + length);
		}catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * 
	 * @param caption
	 * @param text
	 * @param type IContext.CONFIRMATION下的五类型
	 * @param image
	 * @param timeOut 0:forever;a positive time value in milliseconds
	 */
	public static void sendMessage(String caption, String text, int type, BufferedImage image, int timeOut){
		if(ContextManager.cmStatus == ContextManager.STATUS_SERVER_SELF){
			String imageData = null;
			if(image != null){
				ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
				try {
					ImageIO.write(image, "png", byteArrayOutputStream);
					byte[] out = byteArrayOutputStream.toByteArray();
					imageData = "&image=" + ByteUtil.encodeBase64(out);
					byteArrayOutputStream.close();
				} catch (IOException e1) {
					e1.printStackTrace();
					return;
				}
			}
			String url = HCURL.CMD_PROTOCAL + "://" + HCURL.DATA_CMD_MSG + 
				"?caption=" + StringUtil.replace(caption, "&", "\\&") + 
				"&text=" + StringUtil.replace(text, "&", "\\&") +
				"&timeOut=" + timeOut +			
				"&type=" + String.valueOf(type) + ((imageData==null)?"":imageData);
			ContextManager.getContextInstance().send(MsgBuilder.E_GOTO_URL, url);
		}
	}

	public static void send(String caption, String text, int type){
		try{
			BackServer.sendMessage(caption, text, type, null, 0);
		}catch (Throwable e) {
			//设计时，手机非在线时，
		}
	}

	public static void alertOn(){
		sendCmd(HCURL.DATA_CMD_ALERT, "status", "on");
	}
	
	public static void alertOff(){
		sendCmd(HCURL.DATA_CMD_ALERT, "status", "off");
	}
	
	public static void vibrate(int duration){
		String[] v = {"hc.j2me.load.Vibrate", String.valueOf(duration)};
		sendCmd(HCURL.DATA_CMD_SendPara, buildParaStringArray(1), v);
	}
	
	public static void playTone(int note, int duration, int volume){
		String[] v = {"hc.j2me.load.Tone", String.valueOf(note), String.valueOf(duration), String.valueOf(volume)};
		sendCmd(HCURL.DATA_CMD_SendPara, buildParaStringArray(3), v);
	}
	
	private static void sendCmd(String cmdType, String[] para, String[] value){
		if(ContextManager.cmStatus == ContextManager.STATUS_SERVER_SELF){
			HCURLUtil.sendCmd(cmdType, para, value);
		}
	}
	
	private static void sendCmd(String cmdType, String para, String value){
		if(ContextManager.cmStatus == ContextManager.STATUS_SERVER_SELF){
			HCURLUtil.sendCmd(cmdType, para, value);
		}
	}
	
	private static String[] buildParaStringArray(final int paraNum){
		String[] p = new String[paraNum + 1];
		p[0] = HCURL.DATA_PARA_CLASS;
		for (int i = 1; i <= paraNum; i++) {
			p[i] = String.valueOf(i);
		}
		return p;
	}
	
	public static void log(String msg){
		L.V = L.O ? false : LogManager.log(msg);
	}
	
	public static void actionKeys(String keys){
		KeyComper.actionKeys(keys);
	}

}
