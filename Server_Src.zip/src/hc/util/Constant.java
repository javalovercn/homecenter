package hc.util;

public class Constant {

	public static final int IMAGE_BYTE_MAX_LEN = 1024;

}
