package hc.util;

public class HCDialog {

}
