package hc.util;

import java.util.HashMap;

public interface IBiz {
	public void setMap(HashMap map);
	
	public void start();
}
