package hc.server.util;

import hc.App;
import hc.core.ContextManager;
import hc.core.IConstant;
import hc.core.IContext;
import hc.core.MsgBuilder;
import hc.core.util.CCoreUtil;
import hc.core.util.CUtil;
import hc.core.util.LogManager;
import hc.server.ui.SingleMessageNotify;

import java.io.InputStream;
import java.io.OutputStream;
import java.security.SecureRandom;
import java.security.Security;

import javax.crypto.Cipher;
import javax.crypto.CipherInputStream;
import javax.crypto.CipherOutputStream;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;

public class ServerCUtil {
	/**
	 * 
	 * @param data
	 * @param offset
	 * @param certKeyLen
	 * @param storeVerifyIdx
	 * @return
	 */
	public static short checkCertKeyAndPwd(byte[] data, int offset, byte[] pwd, byte[] certKey, byte[] oldData){
		if(CUtil.isSecondCertKeyError == false){
			//解决因证书新传后，再次验证时，导致重复操作。
			CUtil.buildCheckCertKeyAndPwd(oldData, offset, pwd, certKey);
		}
		
		//注意与普通数据加解密的次序相反
		if(CUtil.userEncrypter != null){
			CUtil.userEncrypter.decryptCertKey(data, offset, CUtil.TRANS_CERT_KEY_LEN);
		}
		
		int endIdx = CUtil.VERIFY_CERT_IDX + CCoreUtil.CERT_KEY_LEN;
		int firstHalfEndIdx = CUtil.VERIFY_CERT_IDX + CCoreUtil.CERT_KEY_LEN / 2;
//		String str1, str2;
//		str1 = "";
//		str2 = "";
		for (int i = endIdx - 1; i >= CUtil.VERIFY_CERT_IDX; i--) {
			int dataIdx = offset + i;
//			str1 += " " + (Integer.toHexString(0xFF & oldData[dataIdx]));
//			str2 += " " + (Integer.toHexString(0xFF & data[dataIdx]));
			
//			System.out.println("Str1 : " + str1);
//			System.out.println("Str2 : " + str2);
			
//			System.out.println("security i:" + i + ", firstEndIdx:" + firstEndIdx);
			if(i < firstHalfEndIdx){
				if(oldData[dataIdx] != data[dataIdx]){
					SingleMessageNotify.showOnce(SingleMessageNotify.TYPE_ERROR_PASS, 
							"Mobile login with ERROR password", "Error Password", 1000 * 60, 
							App.getSysIcon(App.SYS_ERROR_ICON));
					LogManager.errToLog("Mobile login with ERROR password");
					return IContext.BIZ_SERVER_AFTER_PWD_ERROR;
				}
			}else{
				if(oldData[dataIdx] != data[dataIdx]){
					return IContext.BIZ_SERVER_AFTER_CERTKEY_ERROR;
				}
			}
		}
		hc.core.L.V=hc.core.L.O?false:LogManager.log("Client pass certkey and password");
		return IContext.BIZ_SERVER_AFTER_CERTKEY_AND_PWD_PASS;
	}

	public static void transCertKey(byte[] oneTimeCertKey, byte msgTag) {
		IContext ic = ContextManager.getContextInstance();
		final byte[] transCKBS = new byte[MsgBuilder.UDP_BYTE_SIZE];
		
		CUtil.generateTransCertKey(transCKBS, MsgBuilder.INDEX_MSG_DATA, oneTimeCertKey, IConstant.passwordBS);
		
		ic.send(msgTag, transCKBS, CUtil.TRANS_CERT_KEY_LEN);
	}


	public static void transOneTimeCertKey() {
		hc.core.L.V=hc.core.L.O?false:LogManager.log("transport one time certification key to client");
		
		//传输OneTimeCertKey
		if(CUtil.OneTimeCertKey == null){
			CUtil.OneTimeCertKey = new byte[CCoreUtil.CERT_KEY_LEN];
		}
		CCoreUtil.generateRandomKey(CUtil.OneTimeCertKey, 0, CCoreUtil.CERT_KEY_LEN);
//		L.V = L.O ? false : LogManager.log("OneTime:" + CUtil.getCode(CUtil.OneTimeCertKey));
		transCertKey(CUtil.OneTimeCertKey, MsgBuilder.E_TRANS_ONE_TIME_CERT_KEY);
	}
	
	private final static String Algorithm = "DES"; // 定义 加密算法,可用DES,DESede,Blowfish

	static {
        Security.addProvider(new com.sun.crypto.provider.SunJCE()); 
	}

	public static InputStream decodeStream(InputStream in, byte[] key)
			throws Exception {
		key = doubePWD(key);
		
		// DES算法要求有一个可信任的随机数源
		SecureRandom sr = new SecureRandom();
		// 创建一个 DESKeySpec 对象,指定一个 DES 密钥
		DESKeySpec ks = new DESKeySpec(key);
		// 生成指定秘密密钥算法的 SecretKeyFactory 对象。
		SecretKeyFactory factroy = SecretKeyFactory.getInstance(Algorithm);
		// 根据提供的密钥规范（密钥材料）生成 SecretKey 对象,利用密钥工厂把DESKeySpec转换成一个SecretKey对象
		SecretKey sk = factroy.generateSecret(ks);
		// 生成一个实现指定转换的 Cipher 对象。Cipher对象实际完成加解密操作
		Cipher c = Cipher.getInstance(Algorithm);
		// 用密钥和随机源初始化此 cipher
		c.init(Cipher.DECRYPT_MODE, sk, sr);

		// 从 InputStream 和 Cipher 构造 CipherInputStream。
		// read() 方法在从基础 InputStream 读入已经由 Cipher 另外处理(加密或解密)
		CipherInputStream cin = new CipherInputStream(in, c);

		return cin;
	}

	public static OutputStream encodeStream(OutputStream out, byte[] key)
			throws Exception {
		key = doubePWD(key);
		
		// 创建一个 DESKeySpec 对象,指定一个 DES 密钥
		DESKeySpec ks = new DESKeySpec(key);
		// 生成指定秘密密钥算法的 SecretKeyFactory 对象。
		SecretKeyFactory factroy = SecretKeyFactory.getInstance(Algorithm);
		// 根据提供的密钥规范（密钥材料）生成 SecretKey 对象,利用密钥工厂把DESKeySpec转换成一个SecretKey对象
		SecretKey sk = factroy.generateSecret(ks);
		
		
//		// 秘密（对称）密钥(SecretKey继承(key))
//		// 根据给定的字节数组构造一个密钥。
//		SecretKey deskey = new SecretKeySpec(new DESKeySpec(key), Algorithm);
		// 生成一个实现指定转换的 Cipher 对象。Cipher对象实际完成加解密操作
		Cipher c = Cipher.getInstance(Algorithm);
		// 用密钥初始化此 cipher
		c.init(Cipher.ENCRYPT_MODE, sk);

		// CipherOutputStream 由一个 OutputStream 和一个 Cipher 组成
		// write() 方法在将数据写出到基础 OutputStream 之前先对该数据进行处理(加密或解密)
		CipherOutputStream cout = new CipherOutputStream(out, c);
		return cout;
	}

	private static byte[] doubePWD(byte[] key) {
		if(key.length <= 8){
			byte[] newKey = new byte[key.length * 2];
			for (int i = 0; i < key.length; i++) {
				newKey[i] = key[i];
			}
			for (int i = key.length, j = 0; i < newKey.length; i++, j++) {
				newKey[i] = key[j];
			}
			return newKey;
		}else{
			return key;
		}
	}
	
}
