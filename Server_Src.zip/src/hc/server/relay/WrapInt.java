package hc.server.relay;

public class WrapInt {
	public int value;
}
