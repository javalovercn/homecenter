package hc.server.relay;

import hc.core.IWatcher;
import hc.core.util.LogManager;

public abstract class RelayShutdownWatch implements IWatcher {
	public void setPara(Object p) {
	}
	
	long start = 0;
	
	public boolean watch() {
		if(start == 0){
			start = System.currentTimeMillis();
		}

		if(System.currentTimeMillis() - start > 30000){
			//发现可替Relay，但是没有回应
			RelayManager.notifyClientsLineOff();

			hc.core.L.V=hc.core.L.O?false:LogManager.log("Stop relay task");
			extShutdown();
			return true;
		}else{
			//等待在途包全部转完，含重发
			try{
				Thread.sleep(200);
			}catch (Exception e) {
				
			}
			return false;
		}
	}
	
	@Override
	public void cancel() {
	}

	@Override
	public boolean isNotCancelable(){
		return false;
	}


	public abstract void extShutdown();
}
