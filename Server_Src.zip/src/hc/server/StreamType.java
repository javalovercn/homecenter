package hc.server;

public class StreamType {

}
