package hc.server.ui;

import hc.core.ContextManager;
import hc.core.MsgBuilder;
import hc.core.util.CtrlKey;
import hc.core.util.OutPortTranser;

public abstract class CtrlResponse {
	public String __hide_currentCtrlID;

	public void onLoad(){
		
	}
	
	public void onExit(){
		
	}

	public abstract void click(int keyValue);
	
	/**
	 * show tip message on mobile after click some key for response.
	 * @param msg
	 */
	public void showTip(String msg){
		OutPortTranser opt = new OutPortTranser();
		opt.out(__hide_currentCtrlID);
		opt.out(CtrlKey.SHOW_TIP);
		opt.out(msg);
		
		ContextManager.getContextInstance().send(MsgBuilder.E_JCIP_FORM_REFRESH, opt.getSubmitString());
	}
	
	public void sendStatus(String key, String value){
		sendStatus(key, value, false);
	}
	
	public void sendStatus(String key, String value, boolean isRTL){
		String[] keyArr = {key};
		String[] vArr = {value};
		sendStatus(keyArr, vArr, isRTL);
	}
	
	/**
	 * send a status to mobile side.
	 * @param key
	 * @param value
	 */
	public void sendStatus(String[] keys, String[] values){
		sendStatus(keys, values, false);
	}
	
	public void sendStatus(String[] keys, String[] values, boolean isRTL){
		OutPortTranser opt = new OutPortTranser();
		opt.out(__hide_currentCtrlID);
		opt.out(CtrlKey.SEND_STATUS);
		opt.out(keys);
		opt.out(values);
		opt.out(isRTL);
		
		ContextManager.getContextInstance().send(MsgBuilder.E_JCIP_FORM_REFRESH, opt.getSubmitString());
	}
}
