package hc.server.ui;

import hc.App;
import hc.core.ConditionWatcher;
import hc.core.IContext;
import hc.core.IWatcher;
import hc.res.ImageSrc;
import hc.util.ResourceUtil;

import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.io.IOException;
import java.util.HashMap;

import javax.imageio.ImageIO;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.KeyStroke;
import javax.swing.SwingConstants;

public class SingleMessageNotify {
	public static final String TYPE_ERROR_CONNECTION = "ErrCon";
	public static final String TYPE_ERROR_PASS = "ErrPass";
	public static final String TYPE_ERROR_CERT = "ErrCert";
	public static final String TYPE_LOCK_CERT = "LockCert";
	public static final String TYPE_FORBID_CERT = "ForbidCert";
	
	private static HashMap<String, Boolean> typeMessageStatus = new HashMap<String, Boolean>();
	private static HashMap<String, JDialog> typeDialogs = new HashMap<String, JDialog>();
	
	public static final void showOnce(final String type, String msg, String title, final int disposeMS, final Icon icon){
		synchronized (SingleMessageNotify.class) {
			if(SingleMessageNotify.isShowMessage(type) == false){
				new SingleMessageNotify(type, msg, title, disposeMS, icon);
				SingleMessageNotify.setShowToType(type, true);
			}
		}
	}
	
	private static final boolean isShowMessage(String type){
		Boolean isShow = typeMessageStatus.get(type);
		if(isShow == null){
			return false;
		}
		return isShow.booleanValue();
	}
	
	private static final void setShowToType(String type, boolean isShow){
		if(isShow){
			typeMessageStatus.put(type, Boolean.TRUE);
		}else{
			typeMessageStatus.remove(type);
		}
	}
	
	private final JDialog dialog;
	
	public SingleMessageNotify(final String type, String msg, String title, final int disposeMS, final Icon icon){
		dialog = new JDialog();
		
		dialog.setTitle(title);
		dialog.setIconImage(App.SYS_LOGO);

		typeDialogs.put(type, dialog);
		
		final ActionListener quitAction = new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				closeDialog(type);
			}
		};
		dialog.getRootPane().registerKeyboardAction(quitAction,
	            KeyStroke.getKeyStroke(KeyEvent.VK_ESCAPE, 0),
	            JComponent.WHEN_IN_FOCUSED_WINDOW);

		ImageIcon iconOK = null;
		try {
			iconOK = new ImageIcon(ImageIO.read(ImageSrc.OK_ICON));
		} catch (IOException e1) {
			e1.printStackTrace();
		}
		final JButton jbOK = new JButton((String) ResourceUtil.get(IContext.OK), iconOK);

		jbOK.addActionListener(quitAction);

		JPanel rootPanel = new JPanel();
		rootPanel.setLayout(new GridBagLayout());
		Insets insets = new Insets(5, 5, 5, 5);
		final JLabel jta = new JLabel("<html><body>"+msg+"</body></html>", icon, SwingConstants.LEFT);
		
		rootPanel.add(jta, new GridBagConstraints(0, 0, 1, 1, 0.0, 0.0, 
				GridBagConstraints.CENTER, GridBagConstraints.BOTH, insets, 0, 0));
		rootPanel.add(jbOK, new GridBagConstraints(0, 1, 1, 1, 0.0, 0.0, 
				GridBagConstraints.EAST, GridBagConstraints.NONE, insets, 0, 0));

		dialog.add(rootPanel);
		
		dialog.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		jbOK.setFocusable(true);
		dialog.getRootPane().setDefaultButton(jbOK);
		jbOK.requestFocus();
		
		dialog.pack();
		dialog.setResizable(false);
		
		App.showCenter(dialog);
		
		//由原CondWatcher改来，采用线程
		new Thread(){
			private long startMS = System.currentTimeMillis();
			@Override
			public void run() {
				while(isShowMessage(type)){
					final long diff = System.currentTimeMillis() - startMS;
					if(diff > disposeMS){
						closeDialog(type);
						break;
					}
					jbOK.setText((String) ResourceUtil.get(IContext.OK) + " [" + (int)((startMS + disposeMS - System.currentTimeMillis()) / 1000) + "]");
					try{
						Thread.sleep(1000);
					}catch (Exception e) {
					}
				}
			}
		}.start();
	}

	public static void closeDialog(final String type) {
		JDialog dialog = typeDialogs.get(type);
		
		if(dialog != null){
			synchronized (SingleMessageNotify.class) {
				if(dialog.isShowing()){
					setShowToType(type, false);
					typeDialogs.put(type, null);
					dialog.dispose();
				}
			}
		}
	}
}
