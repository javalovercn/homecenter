package hc.server.ui;

import hc.core.IConstant;
import hc.core.util.HCURL;
import hc.core.util.HCURLUtil;

import java.net.URLEncoder;

import javax.swing.JPanel;

public class Mlet extends JPanel implements ICanvas{
	public static final String URL_EXIT = HCURL.URL_CMD_EXIT;
	public static final String URL_SCREEN = HCURL.URL_HOME_SCREEN;
	
	public void go(String url){
		try {
			String encodeURL = URLEncoder.encode(url, IConstant.UTF_8);
			HCURLUtil.sendCmd(HCURL.DATA_CMD_SendPara, HCURL.DATA_PARA_TRANSURL, encodeURL);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Override
	public void onStart() {
	}

	@Override
	public void onPause() {
	}

	@Override
	public void onResume() {
	}

	@Override
	public void onExit() {
	}
}
