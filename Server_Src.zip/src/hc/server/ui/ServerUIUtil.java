package hc.server.ui;

import javax.swing.JFrame;

import hc.core.ContextManager;
import hc.core.MsgBuilder;
import hc.core.RootServerConnector;
import hc.core.sip.SIPManager;
import hc.core.util.LogManager;
import hc.server.AbstractDelayBiz;
import hc.server.DelayServer;
import hc.util.BackServer;
import hc.util.HttpUtil;
import hc.util.PropertiesManager;

public class ServerUIUtil {
	public static final Boolean LOCK = new Boolean(true);

	public static boolean useMainCanvas = PropertiesManager.isTrue(PropertiesManager.p_IsMobiMenu);
	private static BackServer responsor;
	
	public static BackServer getResponsor(){
		//加锁，以确保获得必须在启动占锁之后
		synchronized (LOCK) {
			return responsor;
		}
	}
	
	private static boolean isStared = false;
	
	public static BackServer restartResponsorServer(){
		synchronized (LOCK) {
			stop();
			
			if(useMainCanvas){
				//MobiUIResponsor
				String className = RootServerConnector.unObfuscate("chs.reev.riud.segi.noMibIUeRpsnoosr");
				try {
					responsor = (BackServer)Class.forName(className).newInstance();
				} catch (Throwable e) {
					LogManager.err("load class:"+className);
					responsor = new DefaultUIResponsor();
				}
			}else{
				responsor = new DefaultUIResponsor();
			}
			try{
				responsor.start();
			}catch (Throwable e) {
				e.printStackTrace();
			}
			
			isStared = true;
			
			return responsor;
		}
	}

	public static void stop() {
		if(responsor != null && isStared){
			try{
				responsor.stop();
			}catch (Throwable e) {
				e.printStackTrace();
			}
			
			isStared = false;
		}
	}

	public static boolean response(String out) {
		ContextManager.getContextInstance().send(MsgBuilder.E_CANVAS_MAIN, out);
		return true;
	}

	public static void promptAndStop(final boolean isQuery, final JFrame parent){
		if(isServing()){
			HttpUtil.notifyStopServer(isQuery, parent);
			
			RootServerConnector.notifyLineOffType(RootServerConnector.LOFF_ServerReq_STR);
			SIPManager.notifyRelineon(false);
		}

		ServerUIUtil.stop();		
	}

	public static boolean isServing() {
		return ContextManager.cmStatus == ContextManager.STATUS_SERVER_SELF;
	}

	public static void restartResponsorServerDelayMode() {
		DelayServer.getInstance().addDelayBiz(new AbstractDelayBiz(null) {
			@Override
			public void doBiz() {
				restartResponsorServer();
			}
		});
	}

}
