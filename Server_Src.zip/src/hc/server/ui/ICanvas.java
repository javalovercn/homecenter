package hc.server.ui;

public interface ICanvas {
	public void onStart();
	
	public void onPause();
	
	public void onResume();
	
	public void onExit();
}
