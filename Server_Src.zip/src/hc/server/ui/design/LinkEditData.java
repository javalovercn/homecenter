package hc.server.ui.design;

public class LinkEditData {
	LinkProjectStore lps;
	String filePath;
	int status;
	int op;
}
