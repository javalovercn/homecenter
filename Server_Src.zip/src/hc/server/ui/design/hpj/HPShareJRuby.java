package hc.server.ui.design.hpj;

public class HPShareJRuby extends HPNode {

	public HPShareJRuby(int type, String name) {
		super(type, name);
	}

	String content = "";
}
