package hc.server.ui.design.hpj;

public interface IModifyStatus {
	public boolean isModified();
	
	public void setModified(boolean modified);
}
