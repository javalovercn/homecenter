package hc.server.ui.design.hpj;

public class HPMenuEvent extends HPNode {
	public HPMenuEvent(int type, String name) {
		super(type, name);
	}
}
