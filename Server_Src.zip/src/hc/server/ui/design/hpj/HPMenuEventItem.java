package hc.server.ui.design.hpj;

public class HPMenuEventItem extends HPShareJRuby {
	public HPMenuEventItem(int type, String name) {
		super(type, name);
	}
}
