package hc.server.ui.design.hpj;

public class HPShareJRubyFolder extends HPNode {

	public HPShareJRubyFolder(int type, String name) {
		super(type, name);
	}

}
