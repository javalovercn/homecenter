package hc.server.ui.design.hpj;

public class HPShareJarFolder extends HPNode {

	public HPShareJarFolder(int type, String name) {
		super(type, name);
	}

}
