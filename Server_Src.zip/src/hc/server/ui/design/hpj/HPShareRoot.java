package hc.server.ui.design.hpj;

public class HPShareRoot extends HPNode{

	public HPShareRoot(int type, String name) {
		super(type, name);
	}

}
