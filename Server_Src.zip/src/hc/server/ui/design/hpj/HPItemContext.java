package hc.server.ui.design.hpj;

import java.util.HashMap;
import java.util.Map;

public class HPItemContext {
	public IModifyStatus modified;
	private Map<String, String> cmdListener = new HashMap<String, String>();
//	public void putListener(String protocal, String elementID, String src){
//		cmdListener.put(protocal + "_" + elementID, src);
//	}
//	
//	public String getListener(String protocal, String elementID){
//		return cmdListener.get(protocal + "_" + elementID);
//	}
	
}
