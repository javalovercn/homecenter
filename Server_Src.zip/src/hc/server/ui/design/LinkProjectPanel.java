package hc.server.ui.design;

import hc.App;
import hc.UIActionListener;
import hc.core.IConstant;
import hc.core.IContext;
import hc.core.L;
import hc.core.util.HCURL;
import hc.core.util.LogManager;
import hc.res.ImageSrc;
import hc.server.AbstractDelayBiz;
import hc.server.FileSelector;
import hc.server.HCTablePanel;
import hc.server.LinkMenuManager;
import hc.server.ui.ClientDesc;
import hc.server.ui.LinkProjectStatus;
import hc.server.ui.ServerUIUtil;
import hc.server.ui.design.hpj.HCjar;
import hc.util.PropertiesManager;
import hc.util.ResourceUtil;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.Window;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.io.File;
import java.io.IOException;
import java.util.Map;
import java.util.Vector;

import javax.imageio.ImageIO;
import javax.swing.ButtonGroup;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.ListSelectionModel;
import javax.swing.SwingConstants;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.event.TableModelListener;
import javax.swing.table.AbstractTableModel;
import javax.swing.table.DefaultTableCellRenderer;

public class LinkProjectPanel extends ProjectListPanel{
	final HCTablePanel tablePanel;
	final JButton designBut, importBut, editBut, removeBut, upBut, downBut;
	final Vector<LinkEditData> delList = new Vector<LinkEditData>(0);
	boolean isChanged = false;
	
	public static final String OP_NEXT_START_UP = "nextStartUp";
	public static final String OP_ASK = "ask";
	public static final String OP_IMMEDIATE = "immediate";
	
	final JRadioButton rb_startup = new JRadioButton(OP_NEXT_START_UP);
	final JRadioButton rb_ask = new JRadioButton(OP_ASK);
	final JRadioButton rb_imme = new JRadioButton(OP_IMMEDIATE);
	final JCheckBox ch_autoUpgrade = new JCheckBox("auto download and upgrade project");
	
	public static final String getNewLinkedInProjOp(){
		final String op = PropertiesManager.getValue(PropertiesManager.p_OpNewLinkedInProjVer, OP_NEXT_START_UP);
		if(op.equals(OP_NEXT_START_UP) || op.equals(OP_ASK) || op.equals(OP_IMMEDIATE)){
			return op;
		}else{
			return OP_NEXT_START_UP;
		}
	}
	
	private LinkProjectStore searchRoot(){
		for (int i = 0; i < LinkProjectManager.MAX_LINK_PROJ_NUM; i++) {
			LinkEditData led = (LinkEditData)data[i][IDX_OBJ_STORE];
			if(led != null){
				if(led.lps.isRoot()){
					return led.lps;
				}
			}else{
				return null;
			}
		}
		return null;
	}
	
	public LinkProjectPanel(JFrame owner, final boolean newFrame, final Component relativeTo) {
		super();
		final JFrame self = owner;
		
		JPanel contentPane = new JPanel();
		
		contentPane.setLayout(new BorderLayout(ClientDesc.hgap, ClientDesc.vgap));
		
		ImageIcon designIco = null;
		try {
			designIco = new ImageIcon(ImageIO.read(ResourceUtil.getResource("hc/res/designer_22.png")));
		} catch (IOException e2) {
			e2.printStackTrace();
		}    					

		designBut = new JButton((String)ResourceUtil.get(9014), designIco);
		designBut.setToolTipText("<html>load selected project to designer." +
				"<br>all changes in this window will discard.</html>");
		upBut = new JButton((String)ResourceUtil.get(9019), new ImageIcon(ImageSrc.UP_SMALL_ICON));
		downBut = new JButton((String)ResourceUtil.get(9020), new ImageIcon(ImageSrc.DOWN_SMALL_ICON));
		removeBut = new JButton((String)ResourceUtil.get(9018), new ImageIcon(ImageSrc.REMOVE_SMALL_ICON));
		importBut = new JButton((String)ResourceUtil.get(9016), new ImageIcon(ImageSrc.ADD_SMALL_ICON));
		importBut.setToolTipText("add HAR project to system.");
//		importBut.setToolTipText("<html>" +
//				"copy and link dynamically other project into the current project,<BR>" +
//				"it is presented as a folder item of current menu, which is an entrance to the linked project</html>");
		editBut = new JButton((String)ResourceUtil.get(9017), new ImageIcon(ImageSrc.MODIFY_SMALL_ICON));
		editBut.setToolTipText("modify the link name and comment of selected project.");
		Object[] defaultRow = {"", null};
		final AbstractTableModel tableModel = new AbstractTableModel() {
			@Override
			public void setValueAt(Object aValue, int rowIndex, int columnIndex) {
				if(columnIndex == COL_NO){
					data[rowIndex][columnIndex] = aValue;
				} else {
					final LinkEditData led = (LinkEditData)data[rowIndex][IDX_OBJ_STORE];
					final LinkProjectStore lps = led.lps;
					if(lps == null){
						return;
					}
					if(columnIndex == COL_PROJ_ID){
						lps.setProjectID((String)aValue);
					}else if(columnIndex == COL_VER){
							lps.setVersion((String)aValue);
					}else if(columnIndex == COL_IS_ROOT){
						if(lps.isRoot()){
							return;
						}
						final LinkProjectStore root_lps = searchRoot();
						if(root_lps != null){
							root_lps.setRoot(false);
//							if(root_lps.getProjectID().equals(HCURL.ROOT_MENU)){
//								root_lps.setProjectID("oldroot");
//							}
						}
						lps.setRoot((Boolean)aValue);
						lps.setActive(true);
						led.op = (LinkProjectManager.STATUS_MODIFIED);
						
						tablePanel.table.repaint();
					}else if(columnIndex == COL_PROJ_ACTIVE){
						if(lps.isRoot()){
							if(lps.isActive()){
								JPanel panel = new JPanel(new BorderLayout());
								panel.add(new JLabel("root project must be active!", App.getSysIcon(App.SYS_ERROR_ICON), SwingConstants.LEADING), BorderLayout.CENTER);
								App.showCenterPanel(panel, 0, 0, (String)ResourceUtil.get(IContext.ERROR), false, null, null, null, null, self, true, false, null);
								return;
							}
						}
						lps.setActive((Boolean)aValue);
						if((Boolean)aValue){
							if(searchRoot() == null){
								lps.setRoot(true);
							}
						}
						tablePanel.table.repaint();
						led.op = (LinkProjectManager.STATUS_MODIFIED);
					}else if(columnIndex == COL_PROJ_LINK_NAME){
						lps.setLinkName((String)aValue);
					}else if(columnIndex == COL_PROJ_DESC){
						lps.setProjectRemark((String)aValue);
					}else if(columnIndex == COL_UPGRADE_URL){
						lps.setProjectUpgradeURL((String)aValue);
					}
				}
			}
			
			@Override
			public void removeTableModelListener(TableModelListener l) {
			}
			
			@Override
			public boolean isCellEditable(int rowIndex, int columnIndex) {
				if(rowIndex < dataRowNum 
						&& (columnIndex == COL_PROJ_ACTIVE 
						  ||columnIndex == COL_IS_ROOT)){
					return true;
				}
				return false;
			}
			
			@Override
			public Object getValueAt(int rowIndex, int columnIndex) {
				if(rowIndex >= dataRowNum){
					return null;
				}

				if(columnIndex == COL_NO){
					return data[rowIndex][columnIndex];
				} else {
					final LinkEditData led = (LinkEditData)data[rowIndex][IDX_OBJ_STORE];
					final LinkProjectStore lps = led.lps;
					if(columnIndex == COL_IS_ROOT){
						return (lps==null)?Boolean.FALSE:(lps.isRoot());
					}else if(columnIndex == COL_PROJ_ID){
						return (lps==null)?"":lps.getProjectID();
					}else if(columnIndex == COL_VER){
						return (lps==null)?LinkProjectStore.DEFAULT_UNKOWN_VER:lps.getVersion();
					}else if(columnIndex == COL_PROJ_ACTIVE){
						return (lps==null)?Boolean.FALSE:lps.isActive();
					}else if(columnIndex == COL_PROJ_LINK_NAME){
						return (lps==null)?"":lps.getLinkName();
					}else if(columnIndex == COL_PROJ_DESC){
						return (lps==null)?"":lps.getProjectRemark();
					}else if(columnIndex == COL_UPGRADE_URL){
						return (lps==null)?"":lps.getProjectUpgradeURL();
					}else{
						return null;
					}
				}
			}
			
			@Override
			public int getRowCount() {
				return data.length;
			}
			
			@Override
			public String getColumnName(int columnIndex) {
				return colNames[columnIndex].toString();
			}
			
			@Override
			public int getColumnCount() {
				return colNames.length;
			}
			
			@Override
			public Class<?> getColumnClass(int columnIndex) {
				switch (columnIndex) {
                case COL_IS_ROOT:
                    return Boolean.class;
                case COL_PROJ_ACTIVE:
                    return Boolean.class;
                default:
                    return String.class;
				}
			}
			
			@Override
			public void addTableModelListener(TableModelListener l) {
			}
		};
		
		dataRowNum = lpsVector.size();
		
		tablePanel = new HCTablePanel(tableModel, data, colNames, defaultRow, dataRowNum, 
				upBut, downBut, removeBut, importBut, editBut,
				//upOrDownMovingBiz
				new AbstractDelayBiz(null){
					@Override
					public void doBiz() {
						isChanged = true;
					}},
				//Remove
				new AbstractDelayBiz(null) {
					@Override
					public void doBiz() {
						final AbstractDelayBiz selfBiz = this;
						final Object[] rows = (Object[])getPara();
						JPanel askPanel = new JPanel();
						askPanel.add(new JLabel("Are you sure to remove linked project?", App.getSysIcon(App.SYS_QUES_ICON), SwingConstants.LEFT));
						App.showCenterPanel(askPanel, 0, 0, "Confirm Delete?", true, null, null, new ActionListener() {
							@Override
							public void actionPerformed(ActionEvent e) {
								final LinkEditData led = (LinkEditData)rows[IDX_OBJ_STORE];
								final LinkProjectStore lps = led.lps;
								
								delList.add(led);
								dataRowNum--;
								if(lps.isRoot()){
									if(dataRowNum > 0){
										final LinkEditData ledzero = (LinkEditData)data[0][IDX_OBJ_STORE];
										LinkProjectStore first = ledzero.lps;
										if(lps != first){
											first.setRoot(true);
										}else{
											//恰好是首个
											((LinkEditData)data[1][IDX_OBJ_STORE]).lps.setRoot(true);
										}
									}
								}
								
								boolean[] back = {true};
								selfBiz.setPara(back);
							}
						}, null, self, true, false, removeBut);
					}
				}, 
				//import
				new AbstractDelayBiz(null) {
					@Override
					public void doBiz() {
						File file = FileSelector.selectImageFile(importBut, FileSelector.HAR_FILTER, true);
						if(file != null){
							Map<String, Object> map = HCjar.loadHar(file, false);
							if(map.isEmpty()){
								JOptionPane.showMessageDialog(self, "Error link other project from har file.", 
										"Error link other project", JOptionPane.ERROR_MESSAGE);
							}else{
								//检查是否存在同名的工程
								final String proj_id = (String)map.get(HCjar.PROJ_ID);
								for (int i = 0; i < dataRowNum; i++) {
									final LinkEditData led = (LinkEditData)data[i][IDX_OBJ_STORE];
									final LinkProjectStore lps = led.lps;
									
									if(lps.getProjectID().equals(proj_id)){
										tablePanel.table.setRowSelectionInterval(i, i);
										
										JOptionPane.showMessageDialog(self, "project ID [" + proj_id + "] " +
												"is used by project [" + lps.getLinkName() + "] at row NO " + (i + 1), 
												"Error add project", JOptionPane.ERROR_MESSAGE);
										return;
									}
								}
								
								LinkNamePanel panel = showInputLinkName(self, "", "", editBut);
								if(checkIsCancle(panel)){
								}else{								
									final LinkEditData led = new LinkEditData();
									final LinkProjectStore lps = new LinkProjectStore();
									led.lps = lps;
									led.filePath = (file.getAbsolutePath());
									led.op = (LinkProjectManager.STATUS_NEW);
									led.status = (LinkProjectManager.STATUS_NEW);
									
									lps.setActive(true);
									lps.setLinkName(panel.linkNameField.getText());
									lps.setProjectRemark(panel.projRemarkField.getText());
									lps.setProjectID(proj_id);
									lps.copyFrom(map);
									Object[] libName = {
										"", led
									};
									setPara(libName);
									
									dataRowNum++;
									
									if(dataRowNum == 1){
										lps.setRoot(true);
									}
									return;
								}
							}
						}
						setPara(null);
					}
				}, true);
		final DefaultTableCellRenderer centerCellRender = new DefaultTableCellRenderer(){
	        public Component getTableCellRendererComponent(
	                JTable table, Object value, boolean isSelected,
	                boolean hasFocus, int row, int column) {
	        	setHorizontalAlignment(CENTER);
		        return super.getTableCellRendererComponent(table, value,
                        isSelected, hasFocus, row, column);
			}
        };
        
        ListSelectionModel selectModel = tablePanel.table.getSelectionModel();
        selectModel.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        selectModel.addListSelectionListener(new ListSelectionListener() {
			@Override
			public void valueChanged(ListSelectionEvent e) {
				final int selectedRow = tablePanel.table.getSelectedRow();
				if(selectedRow >= 0){
					LinkEditData led = (LinkEditData)data[selectedRow][IDX_OBJ_STORE];
					designBut.setEnabled(led != null);
				}
			}
		});
    	
        designBut.setEnabled(dataRowNum > 0);

    	tablePanel.table.getColumnModel().getColumn(COL_NO).setCellRenderer(centerCellRender);
        tablePanel.table.getColumnModel().getColumn(COL_VER).setCellRenderer(centerCellRender);
        
        initTable(tablePanel.table);
		
		editBut.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				LinkEditData led = (LinkEditData)data[tablePanel.table.getSelectedRow()][IDX_OBJ_STORE];
				LinkProjectStore lps = led.lps;
				
				LinkNamePanel panel = showInputLinkName(self, lps.getLinkName(), lps.getProjectRemark(), editBut);
				if(checkIsCancle(panel)){
					return;
				}
				final String newLinkName = panel.linkNameField.getText();
				final String newComment = panel.projRemarkField.getText();
				if(newLinkName.equals(lps.getLinkName())
						&& newComment.equals(lps.getProjectRemark())){
					//相同或取消
				}else{
					led.op = (LinkProjectManager.STATUS_MODIFIED);

					lps.setLinkName(newLinkName);
					lps.setProjectRemark(newComment);
					
					tablePanel.table.updateUI();
				}
			}
		});
		JPanel buttonsList = new JPanel();
		buttonsList.setLayout(new GridLayout(1, 5, ClientDesc.hgap, ClientDesc.vgap));
		buttonsList.add(designBut);
		buttonsList.add(upBut);
		buttonsList.add(downBut);
		buttonsList.add(removeBut);
		buttonsList.add(editBut);
		buttonsList.add(importBut);

		final String save = (String) ResourceUtil.get(1017);

		final JScrollPane scrollpane = new JScrollPane(tablePanel.table);
		scrollpane.setPreferredSize(new Dimension(800, 250));
		contentPane.add(scrollpane, BorderLayout.CENTER);
		contentPane.add(buttonsList, BorderLayout.NORTH);
		{
			final JLabel comp = new JLabel("choose operation after download new version :");
			JPanel panel = new JPanel(new BorderLayout());
			final JPanel group = new JPanel(new FlowLayout());
			{
				String op = getNewLinkedInProjOp();
				
				final ButtonGroup bg = new ButtonGroup();
				rb_startup.setToolTipText("new version project(s) will apply at next start up.");
				bg.add(rb_startup);
				group.add(rb_startup);
				if(op.equals(OP_NEXT_START_UP)){
					rb_startup.setSelected(true);
				}
				
				rb_ask.setToolTipText("ask whether apply immediately or not");
				bg.add(rb_ask);
				group.add(rb_ask);
				if(op.equals(OP_ASK)){
					rb_ask.setSelected(true);
				}
				
				rb_imme.setToolTipText("apply immediately, may not work properly.");
				bg.add(rb_imme);
				group.add(rb_imme);
				if(op.equals(OP_IMMEDIATE)){
					rb_imme.setSelected(true);
				}
				
				ch_autoUpgrade.addItemListener(new ItemListener() {
					@Override
					public void itemStateChanged(ItemEvent e) {
						final boolean selected = ch_autoUpgrade.isSelected();
						comp.setEnabled(selected);
						rb_startup.setEnabled(selected);
						rb_ask.setEnabled(selected);
						rb_imme.setEnabled(selected);
					}
				});
				ch_autoUpgrade.setToolTipText("<html>if project is <strong>active</strong> and config value of <strong>" + upgradeURL + "</strong></html>");
				ch_autoUpgrade.setSelected(!PropertiesManager.getValue(
					PropertiesManager.p_EnableLinkedInProjUpgrade, IConstant.TRUE).equals(IConstant.TRUE));
				ch_autoUpgrade.doClick();
			}
			JPanel titl_group = new JPanel(new FlowLayout(FlowLayout.LEADING));
			titl_group.add(comp);
			titl_group.add(group);
			
			{
				JPanel checkPanel = new JPanel(new BorderLayout());
				checkPanel.add(ch_autoUpgrade, BorderLayout.NORTH);
				checkPanel.add(titl_group, BorderLayout.CENTER);
				panel.add(checkPanel, BorderLayout.NORTH);				
			}
			panel.add(new JLabel("<html><STRONG>Description</STRONG>:" + 
					"<BR><strong>is Root</strong> : root project will be presented as main menu, other projects are presented as folders of main menu." +
					"<BR>if mobile is online and project is in using, " +
						"click '" + save + "' will break off service, " +
								"and restart all active projects.</html>"), BorderLayout.CENTER);
			contentPane.add(panel, BorderLayout.SOUTH);
		}
		ImageIcon okIco = null;
		try {
			okIco = new ImageIcon(ImageIO.read(ImageSrc.OK_ICON));
		} catch (IOException e1) {
		}
		JButton okBut = new JButton(save, okIco);
		final String exitText = (String) ResourceUtil.get(1011);
		
		final ActionListener cancelListener = new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				LinkProjectStatus.exitStatus();
			}
		};
		JButton jbCancle = new JButton(((exitText == null)?(String) ResourceUtil.get(1018):exitText),
				new ImageIcon(ImageSrc.CANCEL_ICON));
		final UIActionListener cancelAction = new UIActionListener() {
			@Override
			public void actionPerformed(Window window, JButton ok,
					JButton cancel) {
				window.dispose();
				if (cancelListener != null) {
					cancelListener.actionPerformed(null);
				}
			}
		};
		final ActionListener listener = new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				synchronized (ServerUIUtil.LOCK) {
					//将已发布，且准备进行删除的进行删除操作
					for (int i = 0; i < delList.size(); i++) {
						LinkEditData led = delList.elementAt(i);
						LinkProjectStore lps = led.lps;
						if(led.status == LinkProjectManager.STATUS_DEPLOYED){
							final boolean result = LinkProjectManager.removeLinkProjectPhic(lps);
							isChanged = isChanged?true:result;
						}
					}
					delList.removeAllElements();
					for (int i = 0; i < dataRowNum; i++) {
						LinkEditData led = (LinkEditData)data[i][IDX_OBJ_STORE];
						LinkProjectStore lps = led.lps;
						if(led.status == LinkProjectManager.STATUS_NEW){
							File source = new File(led.filePath);
							final boolean result = LinkProjectManager.importLinkProject(lps, source);
							led.status = LinkProjectManager.STATUS_DEPLOYED;
							isChanged = isChanged?true:result;
						}else if(led.op == LinkProjectManager.STATUS_MODIFIED){
							isChanged = true;
						}
						led.op = (LinkProjectManager.STATUS_NEW);
					}
					if(rb_startup.isSelected()){
						PropertiesManager.setValue(PropertiesManager.p_OpNewLinkedInProjVer, OP_NEXT_START_UP);
					}else if(rb_ask.isSelected()){
						PropertiesManager.setValue(PropertiesManager.p_OpNewLinkedInProjVer, OP_ASK);
					}else if(rb_imme.isSelected()){
						PropertiesManager.setValue(PropertiesManager.p_OpNewLinkedInProjVer, OP_IMMEDIATE);
					}

					PropertiesManager.setValue(PropertiesManager.p_EnableLinkedInProjUpgrade, ch_autoUpgrade.isSelected()?IConstant.TRUE:IConstant.FALSE);
					
					PropertiesManager.saveFile();
					
					if(isChanged){
//						L.V = L.O ? false : LogManager.log("restarting service...");
						ServerUIUtil.promptAndStop(true, self);
						
						storeData();
						
						//由于上行已更新，所以可以采用searchRoot
						final LinkProjectStore root = LinkProjectManager.searchRoot();
						if(root != null){
							Designer.setProjectOn();
						}else{
							Designer.setProjectOff();	
						}
						
						Designer design = Designer.getInstance();
						if(design != null){
							design.refresh();
						}
						
						//启动远屏或菜单
						ServerUIUtil.restartResponsorServerDelayMode();
						isChanged = false;
					}
				}
			}
		};
		final UIActionListener jbOKAction = new UIActionListener() {
			@Override
			public void actionPerformed(Window window, JButton ok,
					JButton cancel) {
				try {
					if (listener != null) {
						listener.actionPerformed(null);
					}
				} catch (Exception ex) {
					ex.printStackTrace();
				}
			}
		};
		final Window dialog;

		final String title = (String)ResourceUtil.get(9059);
		if (newFrame) {
			dialog = new JFrame(title);
		} else {
			dialog = new JDialog(owner, title, true);
		}
		designBut.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				dialog.dispose();
				LinkProjectStatus.exitStatus();
				
				final LinkEditData de_led = (LinkEditData)data[tablePanel.table.getSelectedRow()][IDX_OBJ_STORE];
				LinkProjectStore lps = de_led.lps;
				Designer d = Designer.getInstance();
				if(d == null){
					LinkMenuManager.startDesigner();
				}
				Designer.getInstance().shiftProject(lps);
			}
		});

		App.showCenterPanelWindow(contentPane, 0, 0, true, okBut,
				jbCancle, jbOKAction, cancelAction, dialog, relativeTo);
	}

	private void storeData() {
		final int size = dataRowNum;
		Object[] objs = new Object[size];
		
		for (int i = 0; i < size; i++) {
			objs[i] = ((LinkEditData)data[i][IDX_OBJ_STORE]).lps.toSerial();
		}
		
		projIDSet.refill(objs);
		projIDSet.save();
		
		LinkProjectManager.reloadLinkProjects();
	}
	
	protected LinkNamePanel showInputLinkName(final JFrame self, final String linkName, final String mem, final Component relativeTo) {
		final LinkNamePanel panel = new LinkNamePanel(linkName, mem);
		App.showCenterPanel(panel, 0, 0, "Input Link Name", false, null, null,
			null, //cancel
		new ActionListener() {
		@Override
		public void actionPerformed(ActionEvent e) {
			panel.linkNameField.setText(panel.CANCLE);
		}
}, self, true, false, relativeTo);
		return panel;
	}

	public boolean checkIsCancle(LinkNamePanel panel) {
		return panel.linkNameField.getText().equals(panel.CANCLE);
	}

}
