package hc.server.ui;

public interface IFormTimer {
	public int getSecondMS();
	
	public String doAutoResponse();
}
