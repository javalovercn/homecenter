package hc.server.ui;

import hc.core.data.DataClientAgent;
import hc.core.util.LogManager;

public class ClientDesc {

	public static int clientWidth;
	public static int clientHight;
	public static boolean isTouchScreen;
	public static boolean isSupportGPS;
	public static String clientLang;
	public static String clientVer;
	public static void refreshClientInfo(DataClientAgent dss){
		hc.core.L.V=hc.core.L.O?false:LogManager.log("Receive client desc, w:" + dss.getWidth() + ", h:" + dss.getHeight());
		
		clientWidth = dss.getWidth();
		clientHight = dss.getHeight();
		isTouchScreen = dss.isTouchScreen();
		isSupportGPS = dss.isSupportGPS();
		clientLang = dss.getClientLang();
		clientVer = dss.getVer();
	}
	public static final int vgap = 5;
	public static final int hgap = 5;

}
