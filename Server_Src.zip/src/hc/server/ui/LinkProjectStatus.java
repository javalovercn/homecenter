package hc.server.ui;

import hc.App;
import hc.core.IContext;
import hc.core.L;
import hc.core.util.LogManager;
import hc.core.util.Stack;
import hc.util.ResourceUtil;

import java.awt.BorderLayout;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingConstants;


public class LinkProjectStatus {
	public static final int MANAGER_IDLE = 1;
	public static final int MANAGER_UPGRADE_DOWNLOADING = 2;
	public static final int MANAGER_DESIGN = 3;
	public static final int MANAGER_IMPORT = 4;
	public static final int MANAGER_JRUBY_INSTALL = 5;

	private static int manager_status = MANAGER_IDLE;
	
	private static Stack stack = new Stack();
	
	private static void setStatus(final int status){
		stack.push(new Integer(manager_status));
		manager_status = status;
//		L.V = L.O ? false : LogManager.log("curr status : " + manager_status);
	}
	
	public static void exitStatus(){
		manager_status = (Integer)stack.pop();
//		L.V = L.O ? false : LogManager.log("after exit status : " + manager_status);
	}
	
	/**
	 * 检查当前状态是否可以进行发布，Link-in Project的添加或维护
	 * return true表示可以进行后续操作
	 */
	public static synchronized boolean tryEnterStatus(JFrame parent, final int toStatus){
		if(manager_status != MANAGER_IDLE){
			if(manager_status != toStatus){
				if(toStatus == MANAGER_UPGRADE_DOWNLOADING){
					//无需提示的优先
					return false;
				}
				
				if(manager_status == MANAGER_UPGRADE_DOWNLOADING){
					showNotify(parent, "system is downloading and upgrading project(s), please wait for a moment.", IContext.ERROR);
					return false;
				}else if(manager_status == MANAGER_IMPORT){
					showNotify(parent, "please close window [" + (String)ResourceUtil.get(9059) + "] first!", IContext.ERROR);
					return false;
				}else if(manager_status == MANAGER_DESIGN){
					if(toStatus == MANAGER_IMPORT && parent != null){
						//仅放行从设计器调用工程选择器
					}else{
						showNotify(parent, "please close window [" + (String)ResourceUtil.get(9034) + "] first!", IContext.ERROR);
						return false;
					}
				}else if(manager_status == MANAGER_JRUBY_INSTALL){
					showNotify(parent, "<html>please wait for a moment, system is downloading JRuby engine." +
//							"<br>if we have finished, a notify window will display." +
							"</html>", 
							IContext.INFO);
					return false;
				}else{
					return false;
				}
			}else{
				if(toStatus == MANAGER_UPGRADE_DOWNLOADING){
					return false;
				}else{
					showNotify(parent, "current window is opened!", IContext.ERROR);
					return false;
				}
			}
		}
		setStatus(toStatus);
		return true;
	}

	private static void showNotify(JFrame parent, String msg, int type) {
		JLabel label = new JLabel(msg, App.getSysIcon(App.SYS_INFO_ICON), SwingConstants.LEADING);
		JPanel panel = new JPanel(new BorderLayout());
		panel.add(label, BorderLayout.CENTER);
		
		App.showCenterPanel(panel, 0, 0, (String)ResourceUtil.get(type), 
				false, null, null, null, null, parent, true, false, null);
	}

}
