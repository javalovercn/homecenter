package hc.server.data;

public interface IDao {
	public void load();
	
	public void save();
}
