package hc.core;

public class L {
	public static boolean O = false;
	public static boolean V = false;
	
	public static void enable(boolean enable){
		O = !enable;
	}
}
