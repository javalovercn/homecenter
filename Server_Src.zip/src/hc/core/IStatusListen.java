package hc.core;

public interface IStatusListen {
	public void notify(short statusFrom, short statusTo);
}
