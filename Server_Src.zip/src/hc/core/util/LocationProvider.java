package hc.core.util;

public class LocationProvider {
	
	/**
	 * 如果没有可用的GPRS，则返回false
	 * @return
	 */
	public static Object getInstance(){
		return null;
	}
}
