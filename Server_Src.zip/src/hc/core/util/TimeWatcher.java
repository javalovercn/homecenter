package hc.core.util;

public abstract class TimeWatcher {
	final int trigMS;
	long lastTime;

	public TimeWatcher(final int trigMS){
		this.trigMS = trigMS;
		lastTime = System.currentTimeMillis();
	}
	
	public void watchTrigger(){
		final long now = System.currentTimeMillis();
		if(now - lastTime > trigMS){
			doBiz();
		}
		lastTime = now;
	}
	
	public abstract void doBiz();
}
