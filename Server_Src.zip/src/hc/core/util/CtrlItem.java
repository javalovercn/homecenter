package hc.core.util;

public class CtrlItem {
	public int center_x, center_y;
	public int halfWidth, halfHeight;
}
