package hc.core.data;

public class ServerConfig {
	private static ServerConfig config;
	
	public static void setInstance(ServerConfig sc){
		config = sc;
	}
	
	public static ServerConfig getInstance(){
		return config;
	}
	
	/**
	 * 存储0表示，要进行MTU最优发现
	 */
	private int MTU;
	
	private int tryMaxMTU;
	
	private boolean isForceUpdateStun;
	
	private String serverToken;

	public static final String SYS_FOLDER_ICON = "Sys_Folder";

	public static final String SYS_DEFAULT_ICON = "Sys_Img";
	
	public String getServerTokenXXX() {
		return serverToken;
	}

	public void setServerTokenXXX(String serverToken) {
		this.serverToken = serverToken;
	}

	public void readFrom(DataServerConfig dsc){
		MTU = dsc.getMTU();
		tryMaxMTU = dsc.getMaxMTU();
		isForceUpdateStun = dsc.isForceUpdateStun();
		serverToken = dsc.getTokenXXX();
	}
	
	public void writeTo(DataServerConfig dsc){
		dsc.setMTU(MTU);
		dsc.setMaxMTU(tryMaxMTU);
		dsc.setForceUpdateStun(isForceUpdateStun);
		dsc.setTokenXXX(serverToken);
	}

	public int getMTU() {
		return MTU;
	}

	public void setMTU(int mtu) {
		MTU = mtu;
	}

	public int getTryMaxMTU() {
		return tryMaxMTU;
	}

	public void setTryMaxMTU(int maxMTU) {
		this.tryMaxMTU = maxMTU;
	}

	public boolean isForceUpdateStunXXXX() {
		return isForceUpdateStun;
	}

	public void setForceUpdateStunXXXX(boolean isForceUpdateStun) {
		this.isForceUpdateStun = isForceUpdateStun;
	}
}
