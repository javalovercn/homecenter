package hc.core.data;

import java.io.UnsupportedEncodingException;

import hc.core.IConstant;
import hc.core.MsgBuilder;
import hc.core.util.ByteUtil;

public class DataServerConfig extends HCData {
	private final int mtu_index = MsgBuilder.INDEX_MSG_DATA;
	private final int max_mtu_index = mtu_index + 2;
	private final int forceUpdateStun_index = max_mtu_index + 2;
	private final int serverToken_index = forceUpdateStun_index + 1;
	private final int serverTokenLen_index = serverToken_index + 128;
	
	
	public static final byte DATA_FORCE_UPDATE_STUN = 1;
	public static final byte DATA_NOT_FORCE_UPDATE_STUN = 0;

	public int getLength() {
		return 5 + 128 + 1;
	}
	
	public void setTokenXXX(String token){
		byte[] tbs = null;
		try {
			tbs = token.getBytes(IConstant.UTF_8);
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
			tbs = token.getBytes();
		}
		bs[serverTokenLen_index] = (byte) (tbs.length & 0xFF);
		for (int i = 0, j = serverToken_index; i < tbs.length; i++) {
			bs[j++] = tbs[i];
		}
	}
	
	public String getTokenXXX(){
		int len = bs[serverTokenLen_index] & 0xFF;
		try {
			return new String(bs, serverToken_index, len, IConstant.UTF_8);
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}
		return new String(bs, serverToken_index, len);
	}
	
	public int getMTU(){
		return ByteUtil.twoBytesToInteger(bs, mtu_index);
	}
	
	public void setMTU(int mtu){
		ByteUtil.integerToTwoBytes(mtu, bs, mtu_index);
	}
	
	public int getMaxMTU() {
		return ByteUtil.twoBytesToInteger(bs, max_mtu_index);
	}

	public void setMaxMTU(int maxMTU) {
		ByteUtil.integerToTwoBytes(maxMTU, bs, max_mtu_index);
	}
	
	public boolean isForceUpdateStun(){
		return (bs[forceUpdateStun_index] == DATA_FORCE_UPDATE_STUN);
	}
	
	public void setForceUpdateStun(boolean update){
		if(update){
			bs[forceUpdateStun_index] = DATA_FORCE_UPDATE_STUN;
		}else{
			bs[forceUpdateStun_index] = DATA_NOT_FORCE_UPDATE_STUN;
		}
	}
}
