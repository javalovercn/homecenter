1. main class : hc.App, project encode:utf-8.
2. JRE 6.0 or above.
3. please read and agree the license file "hc_license.txt" and "mpl_license.txt".
4. starter.jar and hc.pem in binary zip, are help to check new version, download, verify and start hc.App 